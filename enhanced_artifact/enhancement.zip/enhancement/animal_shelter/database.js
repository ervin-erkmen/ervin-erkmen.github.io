import mysql from 'mysql2'

import dotenv from 'dotenv'
dotenv.config()

/*
MYSQL_HOST='127.0.0.1'
MYSQL_USER='root'
MYSQL_PASSWORD='apple'
MYSQL_DATABASE='animal_shelter'
*/
const pool = mysql.createPool({
    host: process.env.MYSQL_HOST,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DATABASE
}).promise()


// C in CRUD. Create a new animal
export async function createAnimal(animal) {
    const {
        id, age_upon_outcome, animal_id, animal_type, breed, color, date_of_birth, datetime,
        monthyear, name, outcome_subtype, outcome_type, sex_upon_outcome, location_lat,
        location_long, age_upon_outcome_in_weeks
    } = animal;

    const [result] = await pool.query(`
        INSERT INTO animals (
            id, age_upon_outcome, animal_id, animal_type, breed, color, date_of_birth, datetime,
            monthyear, name, outcome_subtype, outcome_type, sex_upon_outcome, location_lat,
            location_long, age_upon_outcome_in_weeks
        ) VALUES (?, ?, ?, ?, ?, ?, STR_TO_DATE(?, '%Y-%m-%dT%H:%i:%s.%fZ'), STR_TO_DATE(?, '%Y-%m-%dT%H:%i:%s.%fZ'), STR_TO_DATE(?, '%Y-%m-%dT%H:%i:%s.%fZ'), ?, ?, ?, ?, ?, ?, ?)
    `, [
        id, age_upon_outcome, animal_id, animal_type, breed, color, date_of_birth, datetime,
        monthyear, name, outcome_subtype, outcome_type, sex_upon_outcome, location_lat,
        location_long, age_upon_outcome_in_weeks
    ]);
    return result;
}



// Read all animals
export async function getAnimals() {
    const [rows] = await pool.query("SELECT* FROM animals")
    return rows;
}

// R in CRUD. Reads animal data based on id
export async function getAnimal(id) {
    const [rows] = await pool.query(`
        SELECT *
        FROM animals
        WHERE id = ?
    `, [id])
    return rows[0];
}

// U in CRUD. Update an animal by ID
export async function updateAnimal(id, animal) {
    const {
        age_upon_outcome, animal_id, animal_type, breed, color, date_of_birth, datetime,
        monthyear, name, outcome_subtype, outcome_type, sex_upon_outcome, location_lat,
        location_long, age_upon_outcome_in_weeks
    } = animal;
    const [result] = await pool.query(`
        UPDATE animals
        SET age_upon_outcome = ?, animal_id = ?, animal_type = ?, breed = ?, color = ?, date_of_birth = STR_TO_DATE(?, '%Y-%m-%dT%H:%i:%s.%fZ'), datetime = STR_TO_DATE(?, '%Y-%m-%dT%H:%i:%s.%fZ'),
            monthyear = STR_TO_DATE(?, '%Y-%m-%dT%H:%i:%s.%fZ'), name = ?, outcome_subtype = ?, outcome_type = ?, sex_upon_outcome = ?, location_lat = ?,
            location_long = ?, age_upon_outcome_in_weeks = ?
        WHERE id = ?

    `, [
        age_upon_outcome, animal_id, animal_type, breed, color, date_of_birth, datetime,
        monthyear, name, outcome_subtype, outcome_type, sex_upon_outcome, location_lat,
        location_long, age_upon_outcome_in_weeks, id
    ]);
    return result.affectedRows > 0;
}

// D in CRUD. Delete an animal by ID
export async function deleteAnimal(id) {
    const [result] = await pool.query(`
        DELETE FROM animals
        WHERE id = ?
    `, [id]);
    return result.affectedRows > 0;
}



