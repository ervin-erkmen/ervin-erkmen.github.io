/*
Author: Ervin Erkmen

Date: 24 August 2024

The purpose of this project was to enhance an artifact in 3 categories: Software engineering, data structures and algorithms, and databases. For all 3 enhancements, I have used my project from CS-340. 
The original artifact was written in python and used MongoDB to store data. For the first enhacement, I have rebuilt the artifact using HTML, CSS, and JavaScript. For the 2nd enhancement, I used quicksort to sort data, a linked list to keep track of which animals
the user clicks on in the table, and I moved the data from MongoDB to MySQL.
*/

let currentPage = 1;
let data = [];
let rowsPerPage = 10;
let sortOrder = {};

// Linked list class. We will use this later to keep track of user's history
class ListNode {
  constructor(data) {
    this.data = data;
    this.next = null;
  }
}

class LinkedList {
  constructor() {
    this.head = null;
    this.tail = null;
  }

  append(data) {
    const newNode = new ListNode(data);
    if (this.tail === null) {
      this.head = newNode;
      this.tail = newNode;
    } else {
      this.tail.next = newNode;
      this.tail = newNode;
    }
  }

  toArray() {
    const result = [];
    let current = this.head;
    while (current !== null) {
      result.push(current.data);
      current = current.next;
    }
    return result;
  }
}

let recentlyViewed = new LinkedList();

// Binary search tree class. We will use this to store the entries in the database, which allows for efficient filtering
class BSTNode {
  constructor(key, data) {
    this.key = key;
    this.data = data;
    this.left = null;
    this.right = null;
  }
}

class BST {
  constructor() {
    this.root = null;
  }

  insert(key, data) {
    const newNode = new BSTNode(key, data);
    if (this.root === null) {
      this.root = newNode;
    } else {
      this.insertNode(this.root, newNode);
    }
  }

  insertNode(node, newNode) {
    if (newNode.key < node.key) {
      if (node.left === null) {
        node.left = newNode;
      } else {
        this.insertNode(node.left, newNode);
      }
    } else {
      if (node.right === null) {
        node.right = newNode;
      } else {
        this.insertNode(node.right, newNode);
      }
    }
  }

  // for the inOrderTraversal, we will use the iterative approach instead of recursive to keep space complexity lower.
  inOrderTraversal(node, result = []) {
    if (node !== null) {
      this.inOrderTraversal(node.left, result);
      result.push(node.data);
      this.inOrderTraversal(node.right, result);
    }
    return result;
  }

  // Using the BST, we will filter the data
  filter(node, criteria) {
    const stack = [];
    const result = [];
    let current = node;

    while (stack.length > 0 || current !== null) {
      if (current !== null) {
        stack.push(current);
        current = current.left;
      } else {
        current = stack.pop();

        if ((criteria.name ? current.data.name === criteria.name : true)) {
          result.push(current.data);
        }

        current = current.right;
      }
    }

    return result;

  }
}

let bst = new BST();

// This function fetches the data from the MySQL database and stores it in the Binary Search Tree
async function fetchData() {

  const response = await fetch('http://localhost:8080/animals');
  data = await response.json();
  loadPage(1);

  data.forEach(item => {
    bst.insert(item.id, item);
  });
}

// Filters data based on criteria
function applyFilter(criteria) {
  const isBlankFilter = !criteria.name;

  if (isBlankFilter) {
    resetFilter();
    return;
  }
 
  let filteredData = data;
  
  filteredData = bst.filter(bst.root, criteria);
  currentPage = 1;
  tempRowsPerPage = filteredData.length;
  displayTable(filteredData, tempRowsPerPage, currentPage);
}

// Event listener for the button that resets the filter. 
document.getElementById('resetFilterButton').addEventListener('click', () => {
  resetFilter();
});

//This function displays all entries and loads back to page 1.
function resetFilter() {
  currentPage = 1;
  updateResultsPerPage;
  displayTable(data, rowsPerPage, currentPage);
  loadPage(1);
}

// Quicksort function. We will use this to efficiently sort the table based on the user's clicks.
function quicksort(arr, key, order = 'asc') {
  if (arr.length <= 1) {
    return arr;
  }

  const pivot = arr[Math.floor(arr.length / 2)][key];
  const left = arr.filter(item => (order === 'asc' ? item[key] < pivot : item[key] > pivot));
  const right = arr.filter(item => (order === 'asc' ? item[key] > pivot : item[key] < pivot));
  const middle = arr.filter(item => item[key] === pivot);

  return [...quicksort(left, key, order), ...middle, ...quicksort(right, key, order)];
}


// sorts the table based on the key selected by the user
function sortTable(key) {

  if (!sortOrder[key]) {
    sortOrder[key] = 'asc';
  } else {
    sortOrder[key] = sortOrder[key] === 'asc' ? 'desc' : 'asc'
  }

  data = quicksort(data, key, sortOrder[key]); // Sort the data
  displayTable(data, rowsPerPage, currentPage); // Update the table display

  updateArrows(key, sortOrder[key]);
}

window.sortTable = sortTable;


// This function is used to manage the arrows that let the user know which column is sorted
// and whether it is in ascending or descending order.
function updateArrows(key, order) {
  // Reset all arrows
  document.querySelectorAll('th span').forEach(span => {
    span.textContent = '↕';
    span.classList.remove('bold-arrow');
  });

  // Update the arrow for the sorted column
  const arrow = document.getElementById(`${key}-arrow`);
  arrow.textContent = order === 'asc' ? '↑' : '↓';
  arrow.classList.add('bold-arrow');
}


// Displays the table
function displayTable(data, rowsPerPage, page) {

  const tableBody = document.getElementById('data-output');
  tableBody.innerHTML = '';

  // Caclualte which entries page will start and end on
  const start = (page - 1) * rowsPerPage;
  const end = start + rowsPerPage;
  const paginatedItems = data.slice(start, end);

  // Create table rows for each entry
  paginatedItems.forEach(item => {
    const row = document.createElement('tr');
    for (const key in item) {

      const cell = document.createElement('td');
      cell.textContent = item[key];
      row.appendChild(cell);

    }

    // Creates a button to the right of each row. This will allow us to select an animal and see it on the map
    const buttonCell = document.createElement('td');
    const button = document.createElement('button');
    button.className = 'round-button';
    button.addEventListener('click', () => {

      document.querySelectorAll('.round-button').forEach(btn => {
        btn.classList.remove('full');
      });

      button.classList.toggle('full');
      console.log('Lat:', item.location_lat, " Long: ", item.location_long);

      // remove current marker if there is one. This way, user only selects one at a time
      if (currentMarker) {
        map.removeLayer(currentMarker);
      }

      currentMarker = L.marker([item.location_lat, item.location_long]).addTo(map)
        .bindPopup(`<b>${item.name}</b><br>Lat: ${item.location_lat}, Long: ${item.location_long}`).openPopup();

      map.setView([item.location_lat, item.location_long], 10);

      window.scrollTo({ top: 0, behavior: 'smooth' });
      
      recentlyViewed.append(item);
      updateRecentlyViewed();

    });
    L.marker([item.location_lat, item.location_long]).addTo(map)
      .bindPopup(`<b>${item.name}</b><br>Lat: ${item.location_lat}, Long: ${item.location_long}`).openPopup();

    buttonCell.appendChild(button);
    row.appendChild(buttonCell);

    tableBody.appendChild(row);
  });
}

// loads the page
async function loadPage(page) {
  // current page iterates down by one if previous page button is hit
  if (page === 'prev' && currentPage > 1) {
    currentPage--;
  } else if (page === 'next' && currentPage * rowsPerPage < data.length) {
    currentPage++;
  } else if (page == 'last' && currentPage * rowsPerPage < data.length) {
    const lastPage = Math.ceil(data.length / rowsPerPage);
    currentPage = lastPage;
  }

  else if (typeof page === 'number') {
    currentPage = page;
  }

  // Add an event listener to update results per page. User can choose results per page 
  document.getElementById("resultsPerPage").addEventListener("change", updateResultsPerPage);
  displayTable(data, rowsPerPage, currentPage);
  updateButtons();
  updatePageNumber();

}

// Event listener for filter
document.getElementById('applyFilterButton').addEventListener('click', () => {
  const name = document.getElementById('name').value;

  applyFilter({ name });
});

document.getElementById('clearRecentlyViewedButton').addEventListener('click', () => {
  recentlyViewed = new LinkedList(); // Reset the linked list
  updateRecentlyViewed(); // Update the display
});

// Enables and disables buttons if first or last page reached. This way, user cannot 
// go to previous if already on first page and cannot go to next if already on last page
function updateButtons() {
  const firstPageButton = document.getElementById('firstPage');
  const prevPageButton = document.getElementById('prevPage');
  const nextPageButton = document.getElementById('nextPage');
  const lastPageButton = document.getElementById('lastPage');

  const lastPage = Math.ceil(data.length / rowsPerPage);

  if (currentPage == 1) {
    firstPageButton.disabled = true;
    prevPageButton.disabled = true;
  } else {
    firstPageButton.disabled = false;
    prevPageButton.disabled = false;
  }

  if (currentPage == lastPage) {
    nextPageButton.disabled = true;
    lastPageButton.disabled = true;
  } else {
    nextPageButton.disabled = false;
    lastPageButton.disabled = false;
  }
}

// Updates total number of pages. Adjusts when rowsPerPage is changed by the user
function updatePageNumber() {
  const pageNumberElement = document.getElementById('pageNumber');
  const totalPages = Math.ceil(data.length / rowsPerPage);
  pageNumberElement.textContent = `Page: ${currentPage} of ${totalPages}`;

}


function updateResultsPerPage() {
  const select = document.getElementById('resultsPerPage');
  const value = select.value;


  rowsPerPage = parseInt(value, 10);


  loadPage(1);
}

// updates the user's history if they click on a button next to a row.
function updateRecentlyViewed() {
  const recentlyViewedContainer = document.getElementById('recently-viewed');
  recentlyViewedContainer.innerHTML = '';

  const recentlyViewedItems = recentlyViewed.toArray();
  recentlyViewedItems.forEach(item => {
    const itemElement = document.createElement('div');
    const name = item.name ? item.name : '(blank)'; // Check for name and use "No Name" if missing
    itemElement.textContent = `ID: ${item.id}, Name: ${name}`;
    recentlyViewedContainer.appendChild(itemElement);
  });
}


fetchData();