import express from 'express';
import cors from 'cors';
import {getAnimals, getAnimal, createAnimal, updateAnimal, deleteAnimal} from './database.js';

const app = express();

app.use(cors());
app.use(express.json());

// Create a new animal
app.post("/animals", async (req, res) => {
    try {
        const animal = req.body;
        const newAnimalId = await createAnimal(animal);
        res.status(201).json({ id: newAnimalId });
    } catch (err) {
        res.status(500).send("Error creating animal: " + err.message);
    }
});

app.get("/animals", async (req, res)=> {
    try {
        const animals = await getAnimals();
        res.json(animals);
    } catch (err) {
        res.status(500).send("Error fetching animals");
    }
})

app.get("/animals/:id", async (req, res)=> {
    try {
        const id = req.params.id;
        const animal = await getAnimal(id);
        res.json(animal);
    } catch (error) {
        res.status(500).send("Error fetching animal");
    }
})

// Update an animal by ID
app.put("/animals/:id", async (req, res) => {
    try {
        const id = req.params.id;
        const animal = req.body;
        const success = await updateAnimal(id, animal);
        if (success) {
            res.status(200).send("Animal updated successfully");
        } else {
            res.status(404).send("Animal not found");
        }
    } catch (err) {
        res.status(500).send("Error updating animal: " + err.message);
    }
});

// Delete an animal by ID
app.delete("/animals/:id", async (req, res) => {
    try {
        const id = req.params.id;
        const success = await deleteAnimal(id);
        if (success) {
            res.status(200).send("Animal deleted successfully");
        } else {
            res.status(404).send("Animal not found");
        }
    } catch (err) {
        res.status(500).send("Error deleting animal: " + err.message);
    }
});

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something broke!');
})

app.listen(8080, () => {
    console.log('Server is running on port 8080');
})